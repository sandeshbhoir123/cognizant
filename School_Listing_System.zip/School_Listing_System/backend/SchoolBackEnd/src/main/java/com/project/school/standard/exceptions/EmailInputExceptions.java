package com.project.school.standard.exceptions;

public class EmailInputExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EmailInputExceptions(String msg) {
		super(msg);
	}
}
