package com.project.school.standard.exceptions;

public class ContactNumberMismatchExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ContactNumberMismatchExceptions(String msg) {
		super(msg);
	}
}
