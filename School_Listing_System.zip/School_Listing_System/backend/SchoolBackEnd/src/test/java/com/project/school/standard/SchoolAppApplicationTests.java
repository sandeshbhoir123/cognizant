package com.project.school.standard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
