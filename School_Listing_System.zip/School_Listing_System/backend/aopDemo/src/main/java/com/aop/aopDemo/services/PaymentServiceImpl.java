package com.aop.aopDemo.services;

public class PaymentServiceImpl implements PayementService {

	public void makepayment() {
		
		System.out.println("Amount Debited");
		
		
		
		System.out.println("Credited");
		
		
	}

}
