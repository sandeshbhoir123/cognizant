package com.aop.aopDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aop.aopDemo.aspectDemo.Myaspect;
import com.aop.aopDemo.services.PayementService;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("com/aop/aopDemo/bean.xml");
       PayementService p= context.getBean("payment",PayementService.class);
     //  Myaspect m=context.getBean("myAspect",Myaspect.class);
       
       p.makepayment();
    }
}
