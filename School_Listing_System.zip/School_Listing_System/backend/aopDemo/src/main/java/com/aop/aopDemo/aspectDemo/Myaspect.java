package com.aop.aopDemo.aspectDemo;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Myaspect {
	
	@Before("execution(* com.aop.aopDemo.services.PaymentServiceImpl.makepayment())")
	public void athonticate() {
		System.out.println("Otp recieved");
	}
	
	@After("execution(* com.aop.aopDemo.services.PaymentServiceImpl.makepayment())")
	public void done() {
		System.out.println("payment done");
	}

}
