package com.aop.aopDemo.services;

public interface PayementService {

	public void makepayment();
}
